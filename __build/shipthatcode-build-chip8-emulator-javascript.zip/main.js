const lines = require("fs").readFileSync(0, "utf8").split("\n");
// TODO (what-is-chip8): implement per the lesson description.
for (const line of lines) {
  if (!line) continue;
  console.log("TODO");
}
